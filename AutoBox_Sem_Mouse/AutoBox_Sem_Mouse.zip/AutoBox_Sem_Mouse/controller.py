"""Decisoes da coleta; nao depende de imagem, navegador ou mouse do Windows."""
from dataclasses import dataclass
from math import hypot, isfinite
import time

def inside(point, area, margin=0):
    x, y = point
    return (area["left"] - margin <= x <= area["left"] + area["width"] + margin
            and area["top"] - margin <= y <= area["top"] + area["height"] + margin)

def center(area):
    return area["left"] + area["width"] / 2, area["top"] + area["height"] / 2

def distance(a, b):
    return hypot(a[0] - b[0], a[1] - b[1])

def detection_area(config, viewport):
    if config.get("full_map", False):
        top = max(0, min(int(config["map"]["top"]), viewport["height"]-1))
        return {"left":config["map"]["left"], "top":top, "width":config["map"]["width"], "height":viewport["height"]-top}
    return dict(config["map"])

def visible_box(point, config):
    # Objetos no minimapa nao sao boxes do espaco.
    return not (config.get("minimap") and inside(point, config["minimap"], margin=3))

def track(candidates, point, radius=60):
    nearby = sorted((candidate for candidate in candidates if distance(candidate[:2], point) <= radius),
                    key=lambda candidate: distance(candidate[:2], point))
    if not nearby:
        return None
    if len(nearby) > 1 and distance(nearby[1][:2], point) - distance(nearby[0][:2], point) < 12:
        return None
    return nearby[0][:2]

@dataclass
class Target:
    point: tuple
    started: float
    last_seen: float
    last_progress: float
    best_distance: float
    last_click: float = -100
    clicks: int = 0
    missing: int = 0
    velocity: tuple = (0., 0.)

class CollectionState:
    def __init__(self, ship):
        self.ship = dict(ship)
        self.origin = center(ship)
        self.arrival_radius = 22
        self.target = None
        self.blocked = []

    def allowed(self, point):
        # Preserva boxes ao lado e embaixo da nave; protege apenas o centro.
        return distance(point, self.origin) > 7

    def choose(self, candidates, now):
        self.blocked = [(point, until) for point, until in self.blocked if until > now]
        available = [p for p in candidates if self.allowed(p[:2])]
        if not available:
            return None
        nearest = min(available, key=lambda p: (distance(p[:2], self.origin), -p[2]))[:2]
        # Nao pula o mais proximo para voar ate outro enquanto aguarda reverificacao.
        if any(distance(nearest, point) <= 18 for point, _ in self.blocked):
            return None
        return nearest

    def acquire(self, point, now):
        self.target = Target(point, now, now, now, distance(point, self.origin))

    def clicked(self, point, now):
        self.target.point = point
        self.target.last_click = now
        self.target.clicks += 1

    def predicted(self, now):
        target = self.target
        elapsed = min(.6, max(0, now-target.last_seen))
        return (target.point[0] + target.velocity[0]*elapsed,
                target.point[1] + target.velocity[1]*elapsed)

    def observe(self, point, now, reward=False):
        target = self.target
        if target is None:
            return "search"
        if reward:
            return "confirmed"
        if now - target.started >= 30:
            return "failed"
        if point is None:
            target.missing += 1
            if (target.missing >= 3 and target.best_distance <= self.arrival_radius
                    and now - target.last_seen >= .6):
                return "departed"
            return "failed" if now - target.last_seen >= 3 else "wait"
        elapsed = now-target.last_seen
        if .04 <= elapsed <= 2:
            vx = (point[0]-target.point[0])/elapsed
            vy = (point[1]-target.point[1])/elapsed
            target.velocity = (vx,vy)
        target.point = point
        target.last_seen = now
        target.missing = 0
        current_distance = distance(point, self.origin)
        if current_distance < target.best_distance - 4:
            target.best_distance = current_distance
            target.last_progress = now
        if now - target.last_progress >= 6:
            return "failed"
        correction_delay = .3 if current_distance < 100 else .9
        if self.allowed(point) and target.clicks < 6 and now - target.last_click >= correction_delay:
            return "aim"
        return "wait"

    def finish(self, now, failed=False):
        if self.target:
            self.blocked.append((self.target.point, now + (2 if failed else .8)))
        self.target = None


class DataFarmPlanner:
    """Motor por identidade e coordenadas; emite decisoes, nunca envia comandos."""
    def __init__(self, arrival_radius=100.):
        self.arrival_radius = arrival_radius
        self.reset()

    def reset(self):
        self.target = None
        self.map_id = None
        self.respawn = None
        self.started = None
        self.last_progress = None
        self.best_distance = float("inf")
        self.last_distance = float("inf")
        self.baseline = None

    @staticmethod
    def key(box):
        return box["id"], box.get("revision")

    def step(self, snapshot, now):
        if not snapshot.get("fresh"):
            self.reset()
            return {"phase":"paused","reason":snapshot.get("status","Aguardando dados atuais.")}
        map_id, respawn = snapshot["map"], snapshot.get("respawn_revision")
        if self.map_id is not None and (map_id!=self.map_id or respawn!=self.respawn):
            self.reset()
            return {"phase":"paused","reason":"Mapa ou renascimento mudou. Plano anterior descartado."}
        self.map_id, self.respawn = map_id, respawn
        if snapshot.get("dead"):
            self.reset()
            return {"phase":"paused","reason":"Nave destruida. Inicie novamente apos recuperar."}
        if snapshot.get("hp_percent") is not None and snapshot["hp_percent"]<=25:
            self.target=None
            return {"phase":"recover","reason":"Vida baixa. Recuperacao automatica ainda nao configurada."}
        position=snapshot["position"]
        boxes=[b for b in snapshot.get("candidates",[]) if b.get("kind") in (None,"box","bonus")]
        if self.target is None:
            if not boxes:
                return {"phase":"search","reason":"Nenhuma box disponivel nos dados."}
            self.target=dict(min(boxes,key=lambda b:distance(position,(b["x"],b["y"]))))
            self.started=self.last_progress=now
            self.best_distance=float("inf")
            self.baseline=snapshot.get("box_counter")
            self.last_distance=float("inf")
        current=next((b for b in boxes if self.key(b)==self.key(self.target)),None)
        if current is None:
            counter=snapshot.get("box_counter")
            confirmed=(self.baseline is not None and counter is not None and counter>self.baseline
                       and self.last_distance<=self.arrival_radius)
            previous=self.target["id"]
            self.target=None
            return {"phase":"confirmed" if confirmed else "unconfirmed",
                    "reason":"Recompensa e desaparecimento observados." if confirmed else
                             "Alvo desapareceu ou mudou sem prova de coleta.",
                    "target_id":previous}
        self.target=dict(current)
        current_distance=distance(position,(current["x"],current["y"]))
        self.last_distance=current_distance
        if current_distance<self.best_distance-5:
            self.best_distance=current_distance
            self.last_progress=now
        speed=snapshot.get("speed")
        eta=current_distance/speed if type(speed) in (int,float) and isfinite(speed) and speed>0 else None
        result={"target_id":current["id"],"revision":current.get("revision"),
                "destination":(current["x"],current["y"]),"distance":current_distance,"eta":eta}
        if now-self.last_progress>=8:
            return dict(result,phase="stalled",reason="Sem aproximacao observada; nao trocar de box.")
        if current_distance<=self.arrival_radius:
            return dict(result,phase="collect",reason="Perto do alvo; aguardar coleta e confirmacao.")
        return dict(result,phase="approach",reason="Aproximar da box selecionada; manter o mesmo ID.")


class DataCollector:
    """Executa um alvo por vez pela interface do cliente; nao monta pacotes HTTP."""
    def __init__(self, session, stop_event, emit, clock=None):
        self.session=session; self.stop=stop_event; self.emit=emit
        self.clock=clock or time.monotonic
        self.planner=DataFarmPlanner(arrival_radius=180)

    def run(self):
        last_status=None; attempted=None
        self.emit("running",True)
        try:
            while not self.stop.is_set():
                snapshot=self.session.get_world_snapshot()
                decision=self.planner.step(snapshot,self.clock())
                phase=decision["phase"]
                status=(phase,decision.get("target_id"))
                if status!=last_status:
                    self.emit("status",decision["reason"]+(" Alvo: "+decision["target_id"] if decision.get("target_id") else ""))
                    last_status=status
                if phase in ("paused","recover","stalled"):
                    if phase=="stalled": self.emit("failed",None)
                    break
                if phase=="confirmed": self.emit("confirmed",None)
                elif phase=="unconfirmed": self.emit("failed",None)
                elif phase in ("approach","collect"):
                    key=(decision["target_id"],decision.get("revision"))
                    if key!=attempted:
                        self.emit("attempt",None); attempted=key
                    if self.stop.is_set(): break
                    self.session.request("data_target",{
                        "map":snapshot["map"],"respawn_revision":snapshot.get("respawn_revision"),
                        "id":decision["target_id"],"revision":decision.get("revision")},
                        allowed=lambda:not self.stop.is_set())
                if self.stop.wait(.15): break
        except Exception as exc:
            self.emit("status","Coleta por dados pausada: "+str(exc))
        finally:
            self.stop.set()
            self.emit("running",False)
